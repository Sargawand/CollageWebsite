<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="user";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);

// Check connection
if ($conn)
 {
  echo "Connected successfully";
}
else 
{
  echo "Connected Faild".mysqli_connect_error();
}
?>

<html>  
<head>  
    

<title>  
Registration Page  
</title>  
</head>
<style>
    body
    {
        height: 100vh;
        width: 100vw;
       
        background: no-repeat;
        /* background-position: cover; */
        background-size: cover;
    }
</style>  
<body style=" background-image: url('./ckt.jpg')">
  
<br>  
<form method="POST" action="data.php"> <b>
  <center >
<label><b>Firstname </b> </label>         
<input type="text" name="firstname" size="15"/> <br> <br>  
<label> Middlename: </label>     
<input type="text" name="middlename" size="15"/> <br> <br>  
<label> Lastname: </label>         
<input type="text" name="lastname" size="15"/> <br> <br>  
  
<label>   

FIELD :  
</label>   
<select>  
<option value="ARTS">ARTS</option>  
<option value="SCIENCE">SCIENCE</option>  
<option value="COMMERCE">COMMERCE</option>  
</select>  
  
<br>  
<br>  

  
<label> 
Phone :  
</label>  
<input type="text" name="country code"  value="+91" size="2"/>   
<input type="text" name="phone" size="10"/> <br> <br>  
Address  
<br>  
<textarea cols="80" rows="5" value="address">  
</textarea>  
<br> <br>  
Email:  
<input type="email" id="email" name="email"/> <br>    
<br> <br>  
Password:  
<input type="Password" id="pass" name="pass"> <br>   
<br> <br>  
Re-type password:  
<input type="Password" id="repass" name="repass"> <br> <br>  
<input type="button" value="Submit" name="sub"/>
</b> </center>  
</form>  

</body>  
</html>