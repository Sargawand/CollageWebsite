<?php
$servername = "localhost";
$username = "root";
$password = "";
$database="student";

// Create connection
$conn = mysqli_connect($servername, $username, $password,$database);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
$status = "";
if(isset($_POST['sub']) && $_POST['sub']==1){
    $Firstname =$_POST['firstname'];
   // $age = $_REQUEST['age'];
   
    $ins_query="insert into register
    (`firstname`)values
    ('$Firstname')";
    mysqli_query($con,$ins_query)
    or die(mysql_error());
    $status = "New Record Inserted Successfully.;
    
}
<p style="color:#FF0000;"><?php echo $status; ?></p>

?>