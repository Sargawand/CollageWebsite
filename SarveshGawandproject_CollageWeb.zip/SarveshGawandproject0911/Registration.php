<?php
include("connect.php");
error_reporting(0)
?>

<html>  
<head>  
    

<title>  
Registration Page  
</title>  
</head>
<style>
    body
    {
        height: 100vh;
        width: 100vw;
       
        background: no-repeat;
        /* background-position: cover; */
        background-size: cover;
    }
</style>  
<body style=" background-image: url('./ckt.jpg')">
  
<br>  
<form method="POST" action=""> <b>
  <center>
<label><b>Firstname </b> </label>         
<input type="text" name="fname" size="15"/> <br> <br>  

<label> Lastname </label>         
<input type="text" name="lname" size="15"/> <br> <br>  
  
<label>   

FIELD :  
</label>   
<select name="field">  
<option value="ARTS">ARTS</option>  
<option value="SCIENCE">SCIENCE</option>  
<option value="COMMERCE">COMMERCE</option>  
</select>  
  
<br>  
<br>  

  
<label> 
Phone :  
</label>  
<input type="text" name="countrycode"  value="+91" size="2"/>   
<input type="text" name="phone" size="10"/> <br> <br>  
Address  
<br>  

<textarea name="address" cols="80" rows="5" value="address">  
</textarea>  
<br> <br>  
Email:  
<input type="email" id="email" name="email"/> <br>    
<br> <br>  
Password:  
<input type="Password" id="pass" name="pass"> <br>   
<br> <br>  
Re-type password:  
<input type="Password" id="repass" name="repass"> <br> <br>  
<input type="submit" value="Submit" name="register"/>
</b> 
</center>  
</form>  

</body>  
</html>
<?php 

if($_POST['register'])
{
  $f_n= $_POST['fname'];
  $l_n= $_POST['lname'];
  $field= $_POST['field'];
  $C_C= $_POST['countrycode'];
  $p_n= $_POST['phone'];
  $add= $_POST['address'];
  $email= $_POST['email'];
  $pass= $_POST['pass'];
  $rpass= $_POST['repass'];

  $query = "INSERT INTO web(Firstname,Lastname,FIELD,Phone,Address,Email,Password,RetypePassword)
   VALUES('$f_n','$l_n','$field','$p_n','$add','$email','$pass','$rpass')";
  $data = mysqli_query($conn,$query);

  if($data)
  {
    echo "Data inserted into data base";
  }
  else
  {
    echo " not inserted ";
  }

}