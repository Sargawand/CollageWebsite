<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname ="sarvesh";

// Create connection
$conn = mysqli_connect($servername,$username,$password,$dbname);

// Check connection
if ($conn)
 {
  echo "Connected successfully";
}
else 
{
  echo "Connected Failed".mysqli_connect_error();
}
?>