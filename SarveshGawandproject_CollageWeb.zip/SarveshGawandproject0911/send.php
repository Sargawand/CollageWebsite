if (isset($_POST['name']) && isset($_POST['contact'])) {
	include 'db_conn.php';

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$name = validate($_POST['name']);
	$contact = validate($_POST['contact']);

	if (empty($contact) || empty($name)) {
		header("Location: register.html");
	}else {

		$sql = "INSERT INTO test(name, contact) VALUES('$name', '$contact')";
		$res = mysqli_query($conn, $sql);

		if ($res) {
			echo "Your contactwas sent successfully!";
		}else {
			echo "Your contact could not be sent!";
		}
	}

}else {
	header("Location: index.html");
}